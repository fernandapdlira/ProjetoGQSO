/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.SQLException;
import model.Bibliotecario;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author leod
 */
public class BibliotecarioControlerTest {
    
    public BibliotecarioControlerTest() throws SQLException {
        Bibliotecario b = new Bibliotecario("name", "login", "password");
        
        BibliotecarioControler controle = new BibliotecarioControler();
        controle.cadastrarBibliotecario(b);
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of cadastrarBibliotecario method, of class BibliotecarioControler.
     */
    @Test
    public void testCadastrarBibliotecario() throws Exception {
        System.out.println("cadastrarBibliotecario");
        Bibliotecario bibliotecario = null;
        BibliotecarioControler instance = new BibliotecarioControler();
        instance.cadastrarBibliotecario(bibliotecario);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
