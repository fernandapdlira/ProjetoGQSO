/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Leticia
 */
public class Bibliotecario {
    private String nome_bibliotecario;
    private String login_bibliotecario;
    private String senha_bibliotecario;

    public Bibliotecario(String nome_bibliotecario, String login_bibliotecario, String senha_bibliotecario) {
        this.nome_bibliotecario = nome_bibliotecario;
        this.login_bibliotecario = login_bibliotecario;
        this.senha_bibliotecario = senha_bibliotecario;
    }

    public String getSenha_bibliotecario() {
        return senha_bibliotecario;
    }

    public void setSenha_bibliotecario(String senha_bibliotecario) {
        this.senha_bibliotecario = senha_bibliotecario;
    }


    public String getNome_bibliotecario() {
        return nome_bibliotecario;
    }

    public void setNome_bibliotecario(String nome_bibliotecario) {
        this.nome_bibliotecario = nome_bibliotecario;
    }

    public String getLogin_bibliotecario() {
        return login_bibliotecario;
    }

    public void setLogin_bibliotecario(String login_bibliotecario) {
        this.login_bibliotecario = login_bibliotecario;
    }

    
    
}
