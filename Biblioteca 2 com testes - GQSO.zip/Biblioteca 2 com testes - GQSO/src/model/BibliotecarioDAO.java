package model;
import java.sql.PreparedStatement;
import java.sql.SQLException;
/**
 *
 * @author Letícia
 */
public class BibliotecarioDAO {
    
    ConnectionFactory connection = new ConnectionFactory(); 
    
    public BibliotecarioDAO() throws SQLException{ 
        connection.getConnection();
    }
    
    public void CadastrarBibliotecario(Bibliotecario bibliotecario) throws SQLException{
        String query = "INSERT INTO Bibliotecarios(nome_bibliotecario, login_bibliotecario, senha_bibliotecario) VALUES(?,?,?)";
        
        PreparedStatement stmt;
        
        stmt = connection.getConnection().prepareStatement(query);
        stmt.setString(1, bibliotecario.getNome_bibliotecario());
        stmt.setString(2, bibliotecario.getLogin_bibliotecario());
        stmt.setString(3, bibliotecario.getSenha_bibliotecario());
        stmt.execute();
        stmt.close();
    
    }
    
}
