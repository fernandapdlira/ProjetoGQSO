/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Letícia
 */
public class ConnectionFactory {
    
    Connection conexao; 
    
    public ConnectionFactory(){
        try{
            conexao = DriverManager.getConnection("jdbc:mysql://localhost/biblioteca", "root", "");
        }
        catch(SQLException ex) {
            JOptionPane.showMessageDialog(null, "Desculpe!\nVocê está desconectado");
            ex.printStackTrace();
        }
    }
    
    public Connection getConnection(){
        return conexao;
    }
    
}
